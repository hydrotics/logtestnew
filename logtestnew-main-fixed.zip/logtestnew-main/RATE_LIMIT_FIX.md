# Rate-limit fix

The bot no longer maintains a second, custom Discord request limiter.

Forum post creation now calls `discord.py` directly. The application still uses a
10-worker job pool so network latency is overlapped, while discord.py remains the
single owner of Discord HTTP rate-limit state.

Why:
- Discord rate limits can be shared across routes/buckets and globally.
- discord.py tracks Discord's bucket hash, major parameters, remaining tokens, and
  reset timing, and pre-emptively waits before exhausting a bucket.
- A route-specific limiter cannot safely reproduce that state and can disagree
  with the library's limiter.

Deployment:
- `requirements.txt` now requires `discord.py>=2.7.1,<2.8`.
- `CREATE_INTERVAL_SECONDS` is no longer read. It can be left in the environment,
  but it has no effect.
- `CREATE_CONCURRENCY` defaults to 10 and is capped in code at 10.
